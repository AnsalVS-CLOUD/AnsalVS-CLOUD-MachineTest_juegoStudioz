//
//  TerrainViewerjuegoApp.swift
//  TerrainViewerjuego
//
//  Created by Ansal on 12/11/25.
//

import SwiftUI

@main
struct TerrainViewerjuegoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
