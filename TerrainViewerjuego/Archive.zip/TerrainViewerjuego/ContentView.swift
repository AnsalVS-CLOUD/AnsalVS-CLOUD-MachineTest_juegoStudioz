//
//  ContentView.swift
//  TerrainViewer
//
//  SwiftUI + RealityKit Terrain Viewer with Trees and Gestures
//

import SwiftUI
import RealityKit
import Combine

struct ContentView: View {
    var body: some View {
        ZStack {
            TerrainARView()
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                HStack {
                    Text("Terrain Viewer")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(8)
                        .background(Color.black.opacity(0.6))
                        .cornerRadius(8)
                    Spacer()
                }
                .padding()
                Spacer()
            }
        }
    }
}

struct TerrainARView: UIViewRepresentable {
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        
        // Configure the AR view
        arView.environment.lighting.intensityExponent = 1.5
        
        // Create anchor
        let anchor = AnchorEntity(world: .zero)
        arView.scene.addAnchor(anchor)
        
        // Load and setup terrain
        context.coordinator.setupTerrain(in: anchor, arView: arView)
        
        // Add gesture recognizers
        let pinchGesture = UIPinchGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handlePinch(_:)))
        let panGesture = UIPanGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handlePan(_:)))
        
        arView.addGestureRecognizer(pinchGesture)
        arView.addGestureRecognizer(panGesture)
        
        context.coordinator.arView = arView
        
        return arView
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator()
    }
    
    class Coordinator: NSObject {
        weak var arView: ARView?
        var cameraEntity: PerspectiveCamera?
        var cameraAnchor: AnchorEntity?
        var cameraDistance: Float = 150.0
        var cameraRotation: SIMD2<Float> = SIMD2(120, 33) // rotX, rotZ
        var cameraTarget: SIMD3<Float> = SIMD3(110, 81, 158)
        
        var lastPanLocation: CGPoint?
        
        func setupTerrain(in anchor: AnchorEntity, arView: ARView) {
            // Create camera
            let camera = PerspectiveCamera()
            let cameraAnchor = AnchorEntity(world: .zero)
            cameraAnchor.addChild(camera)
            arView.scene.addAnchor(cameraAnchor)
            
            self.cameraEntity = camera
            self.cameraAnchor = cameraAnchor
            
            // Load data files
            guard let elevationData = loadElevationData(),
                  let vectorData = loadVectorData() else {
                print("Failed to load data files")
                return
            }
            
            // Create terrain mesh
            let terrainEntity = createTerrainMesh(from: elevationData)
            anchor.addChild(terrainEntity)
            
            // Add trees
            if let trees = vectorData.Tree?.Shapes?.Shape {
                addTrees(trees, to: anchor, elevationData: elevationData)
            }
            
            // Add clubhouse
            if let clubhouse = vectorData.Clubhouse?.Shapes?.Shape {
                addClubhouse(clubhouse, to: anchor, elevationData: elevationData)
            }
            
            // Add water features
            if let water = vectorData.Water?.Shapes?.Shape {
                addWater(water, to: anchor, elevationData: elevationData)
            }
            
            // Add holes (fairways, greens, teeboxes)
            if let holes = vectorData.Holes?.Hole {
                addHoles(holes, to: anchor, elevationData: elevationData)
            }
            
            // Add paths
            if let paths = vectorData.Path?.Shapes?.Shape {
                addPaths(paths, to: anchor, elevationData: elevationData)
            }
            
            // Add bridges
            if let bridges = vectorData.Bridge?.Shapes?.Shape {
                addBridges(bridges, to: anchor, elevationData: elevationData)
            }
            
            // Add creeks
            if let creeks = vectorData.Creek?.Shapes?.Shape {
                addCreeks(creeks, to: anchor, elevationData: elevationData)
            }
            
            // Position camera
            updateCameraPosition()
        }
        
        func loadElevationData() -> ElevationData? {
            guard let url = Bundle.main.url(forResource: "Elevation", withExtension: "json"),
                  let data = try? Data(contentsOf: url),
                  let elevation = try? JSONDecoder().decode(ElevationData.self, from: data) else {
                return nil
            }
            return elevation
        }
        
        func loadVectorData() -> VectorData? {
            guard let url = Bundle.main.url(forResource: "vector", withExtension: "json"),
                  let data = try? Data(contentsOf: url),
                  let vector = try? JSONDecoder().decode(VectorData.self, from: data) else {
                return nil
            }
            return vector
        }
        
        func createTerrainMesh(from elevationData: ElevationData) -> ModelEntity {
            let latPoints = elevationData.latPoints
            let longPoints = elevationData.longPoints
            
            var positions: [SIMD3<Float>] = []
            var indices: [UInt32] = []
            var textureCoordinates: [SIMD2<Float>] = []
            
            // Generate vertices
            for lat in 0..<latPoints {
                for lon in 0..<longPoints {
                    let x = Float(lon)
                    let z = Float(lat)
                    let y = Float(elevationData.elevationArray[lat][lon]) * 0.1 // Scale elevation
                    
                    positions.append(SIMD3<Float>(x, y, z))
                    
                    // Texture coordinates with tiling
                    let u = Float(lon) / Float(longPoints) * 10.0 // Repeat texture 10 times
                    let v = Float(lat) / Float(latPoints) * 10.0
                    textureCoordinates.append(SIMD2<Float>(u, v))
                }
            }
            
            // Generate indices for triangles
            for lat in 0..<(latPoints - 1) {
                for lon in 0..<(longPoints - 1) {
                    let topLeft = UInt32(lat * longPoints + lon)
                    let topRight = topLeft + 1
                    let bottomLeft = UInt32((lat + 1) * longPoints + lon)
                    let bottomRight = bottomLeft + 1
                    
                    // First triangle
                    indices.append(contentsOf: [topLeft, bottomLeft, topRight])
                    // Second triangle
                    indices.append(contentsOf: [topRight, bottomLeft, bottomRight])
                }
            }
            
            // Create mesh descriptor
            var descriptor = MeshDescriptor(name: "terrain")
            descriptor.positions = MeshBuffer(positions)
            descriptor.primitives = .triangles(indices)
            descriptor.textureCoordinates = MeshBuffer(textureCoordinates)
            
            // Generate normals for lighting
            let normals = generateNormals(positions: positions, indices: indices)
            descriptor.normals = MeshBuffer(normals)
            
            // Create mesh resource
            let mesh = try! MeshResource.generate(from: [descriptor])
            
            // Create material with grass texture
            var material = SimpleMaterial()
            material.color = .init(tint: .init(red: 0.3, green: 0.6, blue: 0.3, alpha: 1.0))
            material.roughness = .float(0.9)
            
            // Create the model entity
            let terrainEntity = ModelEntity(mesh: mesh, materials: [material])
            
            // Center the terrain
            let centerX = Float(longPoints) / 2.0
            let centerZ = Float(latPoints) / 2.0
            terrainEntity.position = SIMD3<Float>(-centerX, 0, -centerZ)
            
            return terrainEntity
        }
        
        func generateNormals(positions: [SIMD3<Float>], indices: [UInt32]) -> [SIMD3<Float>] {
            var normals = [SIMD3<Float>](repeating: SIMD3<Float>(0, 1, 0), count: positions.count)
            
            // Calculate face normals and accumulate
            for i in stride(from: 0, to: indices.count, by: 3) {
                let i0 = Int(indices[i])
                let i1 = Int(indices[i + 1])
                let i2 = Int(indices[i + 2])
                
                let v0 = positions[i0]
                let v1 = positions[i1]
                let v2 = positions[i2]
                
                let edge1 = v1 - v0
                let edge2 = v2 - v0
                let normal = normalize(cross(edge1, edge2))
                
                normals[i0] += normal
                normals[i1] += normal
                normals[i2] += normal
            }
            
            // Normalize
            return normals.map { normalize($0) }
        }
        
        func addTrees(_ trees: [TreeShape], to anchor: AnchorEntity, elevationData: ElevationData) {
            for tree in trees {
                let points = tree.parsedPoints
                guard let firstPoint = points.first else { continue }
                
                // Convert lat/lon to terrain coordinates
                let lon = firstPoint.x
                let lat = firstPoint.y
                
                let x = Float((lon - elevationData.minLongitude) / elevationData.step)
                let z = Float((elevationData.maxLatitude - lat) / elevationData.step)
                
                // Get elevation at this point
                let latIndex = Int(z)
                let lonIndex = Int(x)
                
                guard latIndex >= 0 && latIndex < elevationData.latPoints &&
                      lonIndex >= 0 && lonIndex < elevationData.longPoints else {
                    continue
                }
                
                let elevation = Float(elevationData.elevationArray[latIndex][lonIndex]) * 0.1
                
                // Create simple tree model
                let treeEntity = createTreeModel(size: tree.Attributes?.Size ?? 1)
                
                // Position tree (accounting for terrain centering)
                let centerX = Float(elevationData.longPoints) / 2.0
                let centerZ = Float(elevationData.latPoints) / 2.0
                treeEntity.position = SIMD3<Float>(x - centerX, elevation, z - centerZ)
                
                anchor.addChild(treeEntity)
            }
        }
        
        func createTreeModel(size: Int) -> ModelEntity {
            // Create a simple tree with a cylinder trunk and cone canopy
            let trunkHeight: Float = 1.0 + Float(size) * 0.3
            let canopyHeight: Float = 2.0 + Float(size) * 0.5
            let canopyRadius: Float = 1.0 + Float(size) * 0.3
            
            // Trunk
            let trunkMesh = MeshResource.generateCylinder(height: trunkHeight, radius: 0.2)
            var trunkMaterial = SimpleMaterial()
            trunkMaterial.color = .init(tint: .init(red: 0.4, green: 0.3, blue: 0.2, alpha: 1.0))
            let trunk = ModelEntity(mesh: trunkMesh, materials: [trunkMaterial])
            trunk.position.y = trunkHeight / 2
            
            // Canopy (sphere for simplicity, cone would require custom mesh)
            let canopyMesh = MeshResource.generateSphere(radius: canopyRadius)
            var canopyMaterial = SimpleMaterial()
            canopyMaterial.color = .init(tint: .init(red: 0.1, green: 0.5, blue: 0.1, alpha: 1.0))
            let canopy = ModelEntity(mesh: canopyMesh, materials: [canopyMaterial])
            canopy.position.y = trunkHeight + canopyHeight / 2
            
            // Combine
            let tree = ModelEntity()
            tree.addChild(trunk)
            tree.addChild(canopy)
            
            return tree
        }
        
        func addClubhouse(_ clubhouses: [ClubhouseShape], to anchor: AnchorEntity, elevationData: ElevationData) {
            for clubhouse in clubhouses {
                let points = clubhouse.parsedPoints
                guard points.count >= 3 else { continue }
                
                // Create clubhouse as a building (extruded polygon)
                if let entity = createPolygonEntity(points: points, elevationData: elevationData,
                                                    height: 5.0, color: .init(red: 0.7, green: 0.6, blue: 0.5, alpha: 1.0)) {
                    anchor.addChild(entity)
                }
            }
        }
        
        func addWater(_ waterShapes: [WaterShape], to anchor: AnchorEntity, elevationData: ElevationData) {
            for water in waterShapes {
                let points = water.parsedPoints
                guard points.count >= 3 else { continue }
                
                // Create water as a flat blue polygon
                if let entity = createPolygonEntity(points: points, elevationData: elevationData,
                                                    height: 0.1, color: .init(red: 0.2, green: 0.5, blue: 0.8, alpha: 0.7)) {
                    anchor.addChild(entity)
                }
            }
        }
        
        func addHoles(_ holes: [HoleData], to anchor: AnchorEntity, elevationData: ElevationData) {
            for hole in holes {
                // Add fairway (light green)
                if let fairwayShapes = hole.Fairway?.Shapes?.Shape {
                    for shape in fairwayShapes {
                        let points = shape.parsedPoints
                        if let entity = createPolygonEntity(points: points, elevationData: elevationData,
                                                            height: 0.05, color: .init(red: 0.4, green: 0.7, blue: 0.3, alpha: 1.0)) {
                            anchor.addChild(entity)
                        }
                    }
                }
                
                // Add green (darker green)
                if let greenShapes = hole.Green?.Shapes?.Shape {
                    for shape in greenShapes {
                        let points = shape.parsedPoints
                        if let entity = createPolygonEntity(points: points, elevationData: elevationData,
                                                            height: 0.08, color: .init(red: 0.2, green: 0.6, blue: 0.2, alpha: 1.0)) {
                            anchor.addChild(entity)
                        }
                    }
                }
                
                // Add teebox (tan)
                if let teeboxShapes = hole.Teebox?.Shapes?.Shape {
                    for shape in teeboxShapes {
                        let points = shape.parsedPoints
                        if let entity = createPolygonEntity(points: points, elevationData: elevationData,
                                                            height: 0.08, color: .init(red: 0.8, green: 0.7, blue: 0.5, alpha: 1.0)) {
                            anchor.addChild(entity)
                        }
                    }
                }
            }
        }
        
        func addPaths(_ pathShapes: [PathShape], to anchor: AnchorEntity, elevationData: ElevationData) {
            for path in pathShapes {
                let points = path.parsedPoints
                guard points.count >= 2 else { continue }
                
                // Create path as a line/strip (gray)
                if let entity = createPathEntity(points: points, elevationData: elevationData,
                                                 width: 2.0, color: .init(red: 0.5, green: 0.5, blue: 0.5, alpha: 1.0)) {
                    anchor.addChild(entity)
                }
            }
        }
        
        func addBridges(_ bridgeShapes: [BridgeShape], to anchor: AnchorEntity, elevationData: ElevationData) {
            for bridge in bridgeShapes {
                let points = bridge.parsedPoints
                guard points.count >= 3 else { continue }
                
                // Create bridge as raised polygon (brown)
                if let entity = createPolygonEntity(points: points, elevationData: elevationData,
                                                    height: 1.0, color: .init(red: 0.6, green: 0.4, blue: 0.2, alpha: 1.0)) {
                    anchor.addChild(entity)
                }
            }
        }
        
        func addCreeks(_ creekShapes: [CreekShape], to anchor: AnchorEntity, elevationData: ElevationData) {
            for creek in creekShapes {
                let points = creek.parsedPoints
                guard points.count >= 2 else { continue }
                
                // Create creek as a blue line/strip
                if let entity = createPathEntity(points: points, elevationData: elevationData,
                                                 width: 3.0, color: .init(red: 0.3, green: 0.6, blue: 0.9, alpha: 0.8)) {
                    anchor.addChild(entity)
                }
            }
        }
        
        func createPolygonEntity(points: [SIMD2<Double>], elevationData: ElevationData,
                                height: Float, color: UIColor) -> ModelEntity? {
            guard points.count >= 3 else { return nil }
            
            var positions: [SIMD3<Float>] = []
            var indices: [UInt32] = []
            
            let centerX = Float(elevationData.longPoints) / 2.0
            let centerZ = Float(elevationData.latPoints) / 2.0
            
            // Convert points to 3D positions
            for point in points {
                let x = Float((point.x - elevationData.minLongitude) / elevationData.step)
                let z = Float((elevationData.maxLatitude - point.y) / elevationData.step)
                
                let latIndex = Int(z.rounded())
                let lonIndex = Int(x.rounded())
                
                guard latIndex >= 0 && latIndex < elevationData.latPoints &&
                      lonIndex >= 0 && lonIndex < elevationData.longPoints else {
                    continue
                }
                
                let elevation = Float(elevationData.elevationArray[latIndex][lonIndex]) * 0.1
                positions.append(SIMD3<Float>(x - centerX, elevation + height, z - centerZ))
            }
            
            guard positions.count >= 3 else { return nil }
            
            // Simple fan triangulation from first vertex
            for i in 1..<(positions.count - 1) {
                indices.append(contentsOf: [0, UInt32(i), UInt32(i + 1)])
            }
            
            var descriptor = MeshDescriptor(name: "polygon")
            descriptor.positions = MeshBuffer(positions)
            descriptor.primitives = .triangles(indices)
            
            let mesh = try! MeshResource.generate(from: [descriptor])
            
            var material = SimpleMaterial()
            material.color = .init(tint: color)
            material.roughness = .float(0.8)
            
            return ModelEntity(mesh: mesh, materials: [material])
        }
        
        func createPathEntity(points: [SIMD2<Double>], elevationData: ElevationData,
                             width: Float, color: UIColor) -> ModelEntity? {
            guard points.count >= 2 else { return nil }
            
            var positions: [SIMD3<Float>] = []
            var indices: [UInt32] = []
            
            let centerX = Float(elevationData.longPoints) / 2.0
            let centerZ = Float(elevationData.latPoints) / 2.0
            let halfWidth = width / 2.0
            
            // Create a strip along the path
            for i in 0..<points.count {
                let point = points[i]
                let x = Float((point.x - elevationData.minLongitude) / elevationData.step)
                let z = Float((point.y - elevationData.minLatitude) / elevationData.step)
                
                let latIndex = Int(z.rounded())
                let lonIndex = Int(x.rounded())
                
                guard latIndex >= 0 && latIndex < elevationData.latPoints &&
                      lonIndex >= 0 && lonIndex < elevationData.longPoints else {
                    continue
                }
                
                let elevation = Float(elevationData.elevationArray[latIndex][lonIndex]) * 0.1
                
                // Calculate perpendicular direction for width
                var perpendicular = SIMD2<Float>(0, 1)
                if i < points.count - 1 {
                    let next = points[i + 1]
                    let direction = SIMD2<Float>(Float(next.x - point.x), Float(next.y - point.y))
                    if length(direction) > 0 {
                        let normalized = normalize(direction)
                        perpendicular = SIMD2<Float>(-normalized.y, normalized.x)
                    }
                }
                
                // Add two vertices (left and right of path)
                let basePos = SIMD3<Float>(x - centerX, elevation + 0.1, z - centerZ)
                positions.append(basePos + SIMD3<Float>(perpendicular.x * halfWidth, 0, perpendicular.y * halfWidth))
                positions.append(basePos - SIMD3<Float>(perpendicular.x * halfWidth, 0, perpendicular.y * halfWidth))
            }
            
            // Create strip triangles
            for i in 0..<(positions.count - 2) {
                if i % 2 == 0 {
                    indices.append(contentsOf: [UInt32(i), UInt32(i + 2), UInt32(i + 1)])
                    indices.append(contentsOf: [UInt32(i + 1), UInt32(i + 2), UInt32(i + 3)])
                }
            }
            
            guard !positions.isEmpty && !indices.isEmpty else { return nil }
            
            var descriptor = MeshDescriptor(name: "path")
            descriptor.positions = MeshBuffer(positions)
            descriptor.primitives = .triangles(indices)
            
            let mesh = try! MeshResource.generate(from: [descriptor])
            
            var material = SimpleMaterial()
            material.color = .init(tint: color)
            material.roughness = .float(0.7)
            
            return ModelEntity(mesh: mesh, materials: [material])
        }
        
        func updateCameraPosition() {
            guard let cameraAnchor = cameraAnchor else { return }
            
            // Convert rotation angles to radians
            let rotX = cameraRotation.x * .pi / 180.0
            let rotZ = cameraRotation.y * .pi / 180.0
            
            // Calculate camera position using spherical coordinates
            let y = cameraDistance * sin(rotX)
            let horizontalDistance = cameraDistance * cos(rotX)
            let x = horizontalDistance * cos(rotZ)
            let z = horizontalDistance * sin(rotZ)
            
            let cameraPosition = cameraTarget + SIMD3<Float>(x, y, z)
            
            // Create look-at transform
            let lookAtTransform = Transform(
                rotation: simd_quatf(lookAt: cameraTarget, from: cameraPosition, up: [0, 1, 0]),
                translation: cameraPosition
            )
            
            // Apply to camera anchor
            cameraAnchor.transform = lookAtTransform
        }
        
        @objc func handlePinch(_ gesture: UIPinchGestureRecognizer) {
            if gesture.state == .changed {
                let scale = Float(gesture.scale)
                cameraDistance /= scale
                cameraDistance = max(50, min(300, cameraDistance)) // Clamp distance
                gesture.scale = 1.0
                updateCameraPosition()
            }
        }
        
        @objc func handlePan(_ gesture: UIPanGestureRecognizer) {
            let location = gesture.location(in: gesture.view)
            
            if gesture.state == .began {
                lastPanLocation = location
            } else if gesture.state == .changed {
                guard let lastLocation = lastPanLocation else { return }
                
                let delta = CGPoint(
                    x: location.x - lastLocation.x,
                    y: location.y - lastLocation.y
                )
                
                // Rotate camera
                cameraRotation.y += Float(delta.x) * 0.3
                cameraRotation.x -= Float(delta.y) * 0.3
                
                // Clamp vertical rotation
                cameraRotation.x = max(10, min(170, cameraRotation.x))
                
                lastPanLocation = location
                updateCameraPosition()
            } else if gesture.state == .ended {
                lastPanLocation = nil
            }
        }
    }
}

// Helper function for look-at quaternion
extension simd_quatf {
    init(lookAt target: SIMD3<Float>, from position: SIMD3<Float>, up: SIMD3<Float>) {
        let forward = normalize(target - position)
        let right = normalize(cross(up, forward))
        let newUp = cross(forward, right)
        
        let m00 = right.x
        let m01 = right.y
        let m02 = right.z
        let m10 = newUp.x
        let m11 = newUp.y
        let m12 = newUp.z
        let m20 = forward.x
        let m21 = forward.y
        let m22 = forward.z
        
        let trace = m00 + m11 + m22
        
        if trace > 0 {
            let s = sqrt(trace + 1.0) * 2
            let w = 0.25 * s
            let x = (m21 - m12) / s
            let y = (m02 - m20) / s
            let z = (m10 - m01) / s
            self.init(ix: x, iy: y, iz: z, r: w)
        } else if m00 > m11 && m00 > m22 {
            let s = sqrt(1.0 + m00 - m11 - m22) * 2
            let w = (m21 - m12) / s
            let x = 0.25 * s
            let y = (m01 + m10) / s
            let z = (m02 + m20) / s
            self.init(ix: x, iy: y, iz: z, r: w)
        } else if m11 > m22 {
            let s = sqrt(1.0 + m11 - m00 - m22) * 2
            let w = (m02 - m20) / s
            let x = (m01 + m10) / s
            let y = 0.25 * s
            let z = (m12 + m21) / s
            self.init(ix: x, iy: y, iz: z, r: w)
        } else {
            let s = sqrt(1.0 + m22 - m00 - m11) * 2
            let w = (m10 - m01) / s
            let x = (m02 + m20) / s
            let y = (m12 + m21) / s
            let z = 0.25 * s
            self.init(ix: x, iy: y, iz: z, r: w)
        }
    }
}

#Preview {
    ContentView()
}
